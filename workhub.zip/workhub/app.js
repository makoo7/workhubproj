var workhubApp = angular.module('workhubApp', ['ui.router']);

const url =  "https://app.marketermagic.com/api/Workhub/";
// const url = "http://192.168.5.143/marketing-magics/public/api/Workhub/";

workhubApp.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/login');

    $stateProvider
        .state('login', {
            url: '/login',
            templateUrl: 'views/login.html',
            controller: 'mainController'
        })
        .state('task', {
            url: '/task',
            templateUrl: 'views/task.html',
            controller: 'taskController'
        })
        .state('timer', {
            url: '/timer',
            templateUrl: 'views/timer.html',
            controller: 'timerController'
        });
}]);


chrome.runtime.sendMessage({greeting: "start"}, function(response) {
});

// Login Controller
workhubApp.controller('mainController', ['$scope', '$state', '$http', 'AuthenticationService', function ($scope, $state, $http, AuthenticationService) {

    $("#login-links").hide();
    $("#logout-btn").hide();
    $("#invalidcred-error").hide();
    // _startScreenCapture();

    if (localStorage.getItem('user')) {
            NextTaskID();   
         $state.go('task'); 
    }

    // chrome.runtime.sendMessage({greeting: "JustStartRecord"}, function(response) {
    //     console.log(response);
    // });

    // function to submit the form after all validation has occurred            
    $scope.submitForm = function (isValid) {

        // check to make sure the form is completely valid
        if (isValid) {
            $scope.credential = { 'email': $scope.email, 'password': $scope.password };
            $scope.form = AuthenticationService.AuthCheck($scope.credential);
        }

    };


}]);

// Task Controller
workhubApp.controller('taskController', ['$scope', '$state', 'AuthenticationService', 'TimerCheckerService', function ($scope, $state, AuthenticationService, TimerCheckerService) {

    $("#login-links").hide();
    $("#logout-btn").show();
    $('[data-toggle="tooltip"]').tooltip();  
    $("#task").attr("disabled", false);
    $scope.projects = [{ 'project_id': 0, 'project_title': 'select' }];

    function CurrentDate(){
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
    
        if (dd < 10) {
        dd = '0' + dd;
        }
    
        if (mm < 10) {
        mm = '0' + mm;
        }
    
        var date =  dd+'-'+mm+'-'+yyyy;
        return date.toString();
    }

    var dates = CurrentDate();

    if((localStorage.getItem('CurrentTaskID') != -1) && (localStorage.getItem('CurrentTaskID')) && localStorage.getItem('TaskArr') != null && localStorage.getItem('user')){

       
              var task = JSON.parse(localStorage.getItem('TaskArr'));

                var taskdate = (typeof task[1] !== "undefined") ? task[1].TaskDate.toString() : task.TaskDate.toString();
                if(taskdate == dates){
                    $(".loading").hide();       
                    $state.go('timer');
                }else{
                    $(".loading").hide();       
                    if(localStorage.removeItem('EventAgeStamps')){ localStorage.removeItem('EventAgeStamps'); }
                    localStorage.setItem('CurrentTaskID', -1);
                    localStorage.removeItem('TaskArr');
                    $state.go('task');
                }

         
           
    }else{
        localStorage.setItem('CurrentTaskID', -1);
        localStorage.removeItem('TaskArr');
        $state.go('task');
    }


    // check if user exists 
    if (localStorage.getItem('user')) {
           
        var user = localStorage.getItem('user');
        var response = AuthenticationService.UserExists(user);
        response.then(function (data) {
            if (data.status == 200) {
                var proj = data.data.projects;
                
                var LoggerSettings = data.data.LoggerSettings;

                if(LoggerSettings != null) {
                    var custom_minutes  = LoggerSettings.custom_minutes;
                    var screens_minutes = LoggerSettings.screens_minutes;
                    var UserSettings = { 'minutes': custom_minutes, 'screens': screens_minutes};
                    // localStorage.setItem('UserSettings', JSON.stringify(UserSettings) );
                }
               
                if(data.data.userlog != undefined){
                    localStorage.setItem('logtiming', data.data.userlog.logtiming);
                    $scope.user_timings = data.data.userlog.updated_at;
                    var time = ConvertMillisecondsToHoursMinsSecs( parseInt(data.data.userlog.logtiming) );
                    $("#todays-work").text((time.Hours +':' +time.Minutes+ ':'+ time.Seconds));
                }
               
                if (proj.length > 0) {
                    $scope.projects = proj;
                }
            }
        });

    }else{
        $state.go('login');
    }

    // select project for fetching task list
    $scope.checktask = function(event){
        
        if(event.project.project_id) {
            var user =  localStorage.getItem('user');
            var projectid = event.project.project_id;

            var response = AuthenticationService.UsersTaskProjectVise(user, projectid);
                response.then(function(data){
                    if(data.status == 200){
                        if(data.data.response.resp_status == "success"){
                            $("#notifi-error").text("no task listed for this project.").hide();
                            var tasklist  = data.data.tasklist;
                            if(tasklist.length > 0){
                                $("#task").attr("disabled", false);
                                $scope.tasklist = tasklist;    
                            }
                         
                        }else if(data.data.response.resp_status == "no_data"){
                            $("#task").attr("disabled", true);
                            $("#notifi-error").text("no task listed for this project.").show();
                        }
                    }
                });
            
        }
        
    } 

    // refresh the list of project and task too.
    $scope.refresh = function() {
        if (localStorage.getItem('user')) {
            var user = localStorage.getItem('user');
                $("#latest-update").html("Refreshing...");
            var response = AuthenticationService.UserExists(user);
                response.then(function (data) {
                    if (data.status == 200) {
                        var proj = data.data.projects;
                        
                        if(data.data.userlog != undefined){
                            $scope.user_timings = data.data.userlog.updated_at;
                            $("#latest-update").html('Last updated at: '+ $scope.user_timings);
                        }

                        if (proj.length > 0) {
                            $scope.projects = proj;
                        }
                    }
                });
        }else{
            $state.go('login');
        }      
    }

    // Logout From Extension
    $("#logout-btn").click(function(){
        localStorage.removeItem('user');
        localStorage.removeItem('CurrentTaskID');
        localStorage.removeItem('TaskArr');
        localStorage.removeItem('TaskTimeStamp');
        localStorage.removeItem('logtiming');
        // localStorage.removeItem('UserSettings');
        chrome.runtime.sendMessage({greeting: "logout"}, function(response) {
        });
        $state.go('login');
    });


    // function to submit the form after all validation has occurred      
    $scope.submitForm = function (isValid) {
        if (isValid) {
            var project = $scope.project;
            var task = $scope.task;
            var user = localStorage.getItem('user');
            $('#start-timer').prop('disabled', true);
            var response = TimerCheckerService.StartTimerAjax(project, task, user);
                response.success(function (data, status, headers, config) {
                
                if(data.response.resp_status == "success"){
                    
                    var Task = data.timerStart;
                        Task.task_title = task;
                    var resp = SubmitTask(project, Task, user);
                    localStorage.setItem( 'CurrentTaskID', resp );
                    $state.go('timer');
                    chrome.runtime.sendMessage({greeting: "startTimer"}, function(response) {
                    });
                } 
            })
            .error(function (data, status, header, config) {
                
                if (status == 401) {
                    $("#task-form").trigger("reset");
                    $("#start-timer").attr("disabled", true);
                }
            });
            
        }
    };

}]);

// Timer Controller
workhubApp.controller('timerController', ['$scope', '$state', '$interval', 'TimerCheckerService', 'AuthenticationService', function ($scope, $state, $interval, TimerCheckerService, AuthenticationService) {

    $("#login-link").hide();
    $("#logout-btn").hide();
    $('[data-toggle="tooltip"]').tooltip();
    
    $(".loading").show();

    chrome.runtime.onMessage.addListener(
        function (request, sender, sendResponse) {
            
            if (request.greeting == "StopTimer") {
                sendResponse({ farewell: "done" });
            }
    });
    
    // Current Task Tracker code starts
     if((localStorage.getItem('CurrentTaskID') != -1) && (localStorage.getItem('CurrentTaskID')) && localStorage.getItem('TaskArr') != null){
        var CurrentTaskID = localStorage.getItem('CurrentTaskID');
        var Task = localStorage.getItem('TaskArr');
        
        TimerCheckerService.StartTimer(CurrentTaskID, Task);

        setTimeout(() => {
            $(".loading").hide();
            $("#current-time").show();
        }, 500);

        if(localStorage.getItem('TaskArr')){
            
           var taskarr = JSON.parse(localStorage.getItem('TaskArr'));


           if(localStorage.getItem('EventAgeStamps')){
            var EventAgeStamps = JSON.parse(localStorage.getItem('EventAgeStamps'));
                EventAgeStamps.pid = taskarr.ProjectId;
                EventAgeStamps.tid = taskarr.TaskId;
                
                localStorage.setItem('EventAgeStamps',  JSON.stringify(EventAgeStamps));
           }  
            
            $interval(function(){
                if(localStorage.getItem('TaskArr')){
                    $(".loading").hide();
                    if(localStorage.getItem('logtiming')){  var logtime = localStorage.getItem('logtiming');  }else{ var logtime = 0; }
                    var Task = JSON.parse(localStorage.getItem('TaskArr'));
                    var ElapsedSince = +Task.ElapsedSince + +logtime;      
                    var secs = ConvertMillisecondsToHoursMinsSecs(ElapsedSince);
                    
                    $("#current-time").text(secs.Hours + ':' + secs.Minutes + ':' + secs.Seconds);
                   
                    $("#current-project").text("Project: "+Task.ProjectName);
                    $("#current-task").text("Task: "+Task.Name);

                }else{
                    return false;
                }
            },500);

        }

    }else{
        $state.go('task');
    }
    // Current Task Tracker code ends

    // Stope Current timer Code start
        $scope.submitForm = function(isValid){
            if (isValid) {
                $("#stop-timer-btn").prop('disabled', true);
                var CurrentTaskID = localStorage.getItem('CurrentTaskID');
                var task = localStorage.getItem('TaskArr');
                var Eventbaselog = localStorage.getItem('EventAgeStamps');
               
                var response = TimerCheckerService.StopeTimerFunc(CurrentTaskID, task, Eventbaselog);
                    response.success(function (data, status, headers, config) {
                           
                        if(data.response.resp_status == "success"){
                                var log = data.userlog;
                                localStorage.setItem('logtiming', log.logtiming);

                                chrome.runtime.sendMessage({greeting: "logoutTimer"}, function(response) {
                                });
                                localStorage.removeItem('TaskArr');
                                localStorage.removeItem('EventAgeStamps');
                                localStorage.setItem('CurrentTaskID', -1);
                                localStorage.removeItem('TaskTimeStamp');
                                $state.go('task');
                        }
                    })
                    .error(function (data, status, header, config) {
                        console.log(data);
                    });
            }
        };
    // Stope Current timer Code ends
    
}]);

/* 
* Services Code start 
*/

workhubApp.service('AuthenticationService', ['$http', '$state', function ($http, $state) {
    // auth check of user 
    this.AuthCheck = function (form) {

        var data = form;

        var config = {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }

        $http.post(url + 'auth', data, config)
            .success(function (data, status, headers, config) {
                    localStorage.setItem('user', JSON.stringify(data.apiuser));
                    chrome.runtime.sendMessage({greeting: "loginsuccess"}, function(response) {
                    });
                    
                    var log = data.userlog;
                    var LoggerSettings = data.LoggerSettings;

                     if(LoggerSettings != null) {
                         var custom_minutes  = LoggerSettings.custom_minutes;
                         var screens_minutes = LoggerSettings.screens_minutes;
                         var UserSettings = { 'minutes': custom_minutes, 'screens': screens_minutes};
                        //  localStorage.setItem('UserSettings', JSON.stringify(UserSettings) );
                     }

                     if(log.logtiming) {
                        localStorage.setItem('logtiming', log.logtiming);
                     }
                $state.go('task');
            })
            .error(function (data, status, header, config) {

                if (status == 401) {
                    $("#invalidcred-error").show();
                    $("#login-form").trigger("reset");
                    $("#signin").attr("disabled", true);
                }

            });

    }

    // check user exists or not

    this.UserExists = function (user) {

        var data = JSON.parse(user);
        var userid = data.user_token;

        return $http.get(url + 'users/' + userid);

    }

    // check users tasklist project vise

    this.UsersTaskProjectVise = function(user, projectid){
        var data = JSON.parse(user);
        var userid = data.user_token;
        var projid = projectid;

        return $http.get(url+'usertask/'+projid+'/'+userid);
    }


    this.CurrentDateToString = function(){
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
    
        if (dd < 10) {
            dd = '0' + dd;
        }
    
        if (mm < 10) {
            mm = '0' + mm;
        }
    
        var date =  dd+'-'+mm+'-'+yyyy;
        return date.toString();
    }

}]);

// Timer Service Code start

workhubApp.service('TimerCheckerService', ['$http', '$state', '$interval', function($http, $state, $interval) {

    this.StartTimer = function(CurrentTaskID, Task) {
        var task = JSON.parse(Task);
        this.UpdateTask(CurrentTaskID, task);
        if(task[CurrentTaskID] != null){
            this.StartTrackingTime(CurrentTaskID, task);
        }
    }

    this.UpdateTask = function(CurrentTaskID, task){
        var task = task;
        if(task[CurrentTaskID] != null){
            task[CurrentTaskID].Timestamp = Date.now().toString();
            task[CurrentTaskID].TotElapsedTime = Date.now().toString();
            localStorage.setItem('TaskArr', JSON.stringify(task));
        }
    }

    this.StartTrackingTime = function(CurrentTaskID, task) {
        $interval(function(){
         
            var HoursMinsSecs  = {},
                Interval       = 0,
                Task           = task[CurrentTaskID],
                TotElapsedTime = parseInt(Task.TotElapsedTime),
                TaskTimestamp  = parseInt(Task.Timestamp);

                Interval = TaskTimestamp - TotElapsedTime;
                HoursMinsSecs = ConvertMillisecondsToHoursMinsSecs( parseInt(Interval) );
                
                $("#current-time").text(HoursMinsSecs.Hours + ':' + HoursMinsSecs.Minutes + ':' + HoursMinsSecs.Seconds);
                
                Task.ElapsedSince = Interval.toString();
                Task.Timestamp = Date.now().toString();
                localStorage.setItem('TaskArr', JSON.stringify(Task));

        },1000);
    }


    this.StopeTimerFunc = function(CurrentTaskID, task, Eventbaselog){
            var task = JSON.parse(task);
            var user = JSON.parse(localStorage.getItem('user'));
            var Eventlog = JSON.parse(Eventbaselog);
            var user_id = user.user_token;
            
            if(user_id != null && task != null) {

                var data = {
                    'user_token' : user_id,
                    'task' : task,
                    'Eventlog' : Eventlog
                };

                var config = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }

                return $http.post(url+'task/stop', data, config);
            }   
    }

    // Start Timer Api log
    this.StartTimerAjax = function(project, task, user) {
        
        var project = project.project_id;
        var task = task;
        var user = JSON.parse(user);
            
            if(task != null && user != null && project != null){
                
                var data = {
                    'project' : project,
                    'task'    : task,
                    'user_token' : user.user_token 
                };

                var config = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }

                return $http.post(url + 'task/create', data, config);
            }
            
    }


}]);

/*
* Services Code ends
*/

/* 
*  Common Servide Code Start 
*/

workhubApp.service('CommonService', ['$state', function($state) {
        
        this.ConvertToTimeZone = function(date){
            return date;
        }
}]);

/* 
*  Common Servide Code Ends 
*/