//  Global
//  IntervalID:  The ID of the currently running timer interval.
//  ID:  A monotonically increasing value to use for generating new task IDs.
var IntervalID = 0;
var ID = 1;    



//------------------------------------------------------------------------------
//
//  Return the next Task ID to be used in the task chiclet DIV.
//
//------------------------------------------------------------------------------
function NextTaskID( )
{   
    var ID = 1;
    return ( ID++ );
}

//------------------------------------------------------------------------------
//
//  Retrieve the TaskArr JSON string from DOM storage, convert it into a
//  JavaScript object, and return it.  If there is no TaskArr in DOM storage, 
//  return an empty JavaScript object.
//
//------------------------------------------------------------------------------
function RetrieveTaskArr( )
{
    var TaskArr_JSON = '',
        TaskArr = {};

    if ( localStorage.getItem('TaskArr') )
    {
        TaskArr_JSON = localStorage.getItem('TaskArr');
        TaskArr      = JSON.parse(TaskArr_JSON);
    }

    return ( TaskArr );

} // RetrieveTaskArr

function CurrentDate(){
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) {
    dd = '0' + dd;
    }

    if (mm < 10) {
    mm = '0' + mm;
    }

    return dd+'-'+mm+'-'+yyyy;
}

//------------------------------------------------------------------------------
//
//  Convert the TaskArr to JSON and save it to local DOM storage.
//
//------------------------------------------------------------------------------
function SaveTaskArr( TaskArr )
{
    var TaskArr_JSON = JSON.stringify(TaskArr);

    localStorage.setItem('TaskArr', TaskArr_JSON);

} // SaveTaskArr


//------------------------------------------------------------------------------
//
//  A linear search through the task array.  Return true if any task's name
//  matches the give TaskName. Otherwise, return false.
//
//------------------------------------------------------------------------------
function TaskAlreadyExistsinArr( TaskArr, TaskName )
{
    for ( var Task in TaskArr )
    {
        if ( TaskArr[Task].Name == TaskName )
        {
            return ( true );
        }
    }

    return ( false );

} // TaskAlreadyExistsinArr


//------------------------------------------------------------------------------
//
//  Via CSS, make the task chiclet appear active.
//
//------------------------------------------------------------------------------
function ActivateTask( TaskID )
{
    var TaskObj  = $( '#' + TaskID ),
       CloseObj = TaskObj.parent().find( '#' + TaskID + '_remove' );

    if ( TaskObj.hasClass('task_mouseover') )
    {   
        TaskObj.removeClass( 'task_mouseover' )
               .addClass( 'task_current_mouseover' );
    }
    else if ( TaskObj.hasClass( 'task_inactive' ) )
    {    
        TaskObj.removeClass( 'task_inactive' )
               .addClass( 'task_current' );
    }

    
} // ActivateTask


//------------------------------------------------------------------------------
//
//  Via CSS, make the task chiclet appear inactive.
//
//------------------------------------------------------------------------------
function DeactivateTask( TaskID )
{
    var TaskArr        = RetrieveTaskArr(),
        Task           = TaskArr[TaskID],
        TaskObj        = $( '#' + TaskID ),
        Timestamp      = parseInt( Task.Timestamp ),
        TotElapsedTime = parseInt( Task.TotElapsedTime ),
        CloseObj       = TaskObj.parent().find( '#' + TaskID + '_remove' );
        
    // if ( TaskObj.hasClass('task_current_mouseover') )
    // {
    //     TaskObj.removeClass( 'task_current_mouseover' ).
    //             addClass( 'task_mouseover' );
    // }
    // else if ( TaskObj.hasClass('task_current') )
    // {
    //     TaskObj.removeClass( 'task_current' )
    //            .addClass( 'task_inactive' );
    // }

    // CloseObj.removeClass( 'close_task_div_active' )
    //         .addClass( 'close_task_div_inactive' );

    // Update the total elapsed time.

    Task.TotElapsedTime = ( TotElapsedTime + (Date.now()-Timestamp) ).toString();
    Task.ElapsedSince = "0";
    TaskArr[TaskID] = Task;
    SaveTaskArr( TaskArr );

} // DeactivateTask


//------------------------------------------------------------------------------
//
//  Convert some number of millisconds to hours, minutes, and seconds and return
//  the converted value.
//
//------------------------------------------------------------------------------
function ConvertMillisecondsToHoursMinsSecs( Milliseconds )
{   
    var NumMillisecondsInHour   = 3600000,
        NumMillisecondsInMinute = 60000,
        NumMillisecondsInSecond = 1000,
        Hours   = 0,
        Minutes = 0,
        Seconds = 0;

    if ( Milliseconds >= NumMillisecondsInHour )
    {
        Hours = parseInt( Milliseconds / NumMillisecondsInHour );
        Milliseconds %= NumMillisecondsInHour;
    }
    
    if ( Milliseconds >= NumMillisecondsInMinute )
    {
        Minutes = parseInt( Milliseconds / NumMillisecondsInMinute );
        Milliseconds %= NumMillisecondsInMinute;
    }

    if ( Milliseconds >= NumMillisecondsInSecond )
    {
        Seconds = parseInt( Milliseconds / NumMillisecondsInSecond );
    }
    
    if(Hours.toString().length  == 1){
        Hours = '0'+Hours;
    }
    if(Minutes.toString().length  == 1){
        Minutes = '0'+Minutes;
    }
    if(Seconds.toString().length  == 1){
        Seconds = '0'+Seconds;
    }

    return( { 'Hours'  : Hours,
              'Minutes': Minutes,
              'Seconds': Seconds } );

} // ConvertMillisecondsToHoursMinsSecs


//------------------------------------------------------------------------------
//
//  Stop the currently active task and, if the user clicked on an inactive task,
//  start that task's timer.
//
//------------------------------------------------------------------------------
function StartTimer( taskid )
{
    
    var TaskID = taskid;

    // if (IntervalID != 0)
    // {
    //     //  Stop the currently running timer
    //     clearInterval( IntervalID );
    //     IntervalID = 0;
    // }
    
    // if ( $this.attr('id') == localStorage.CurrentTaskID )
    // {
    //     //  User clicked on the current task.  Clear the current task, and be
    //     //  done.
    //     // DeactivateTask( localStorage.CurrentTaskID );
    // }
    // else
    // {
        
        TaskArr = RetrieveTaskArr();
        // TODO
        // TaskArr[TaskID].Timestamp = Date.now().toString()?
        Task = TaskArr[TaskID];
        Task.Timestamp = Date.now().toString();
        TaskArr[TaskID] = Task;
        SaveTaskArr( TaskArr );

        //
        //  User clicked on a task other than the current task.  Start the timer
        //  and record which task is the current one.
        IntervalID = setInterval(function() {
            var HoursMinsSecs  = {},
                Interval       = 0,
                TaskArr        = RetrieveTaskArr( );
                Task           = TaskArr[TaskID],
                TotElapsedTime = parseInt(Task.TotElapsedTime),
                TaskTimestamp  = parseInt(Task.Timestamp);
                // Timer          = $this.find( '#' + TaskID + '_timer' );

            //  How long has it been since the timer was started?
            Interval = Date.now() - TaskTimestamp;

            //  Convert the total running time, in ms, to hours/mins/secs.
            HoursMinsSecs = ConvertMillisecondsToHoursMinsSecs( Interval + TotElapsedTime );

            console.log(HoursMinsSecs.Hours + ':' + HoursMinsSecs.Minutes + ':' + HoursMinsSecs.Seconds);

            //  Update the timer in the DOM.
            // Timer.text(HoursMinsSecs.Hours + ':' + HoursMinsSecs.Minutes + ':' + HoursMinsSecs.Seconds);

            //  Save, to DOM local storage, how much time has passed since the
            //  timer was last started so that, if the window is closed while
            //  the timer is still running, we can properly restore the task
            //  when the page is re-loaded.
            Task.ElapsedSince = Interval.toString();
            TaskArr[TaskID] = Task;
            SaveTaskArr( TaskArr );
        }, 1000); // setInterval
        

        //
        //  Deactivate the previously current task, if there was one, record the
        //  new current task's name, and active the new current task.
        // if ( localStorage.getItem('CurrentTaskID') )
        // {
        //     if ( parseInt(localStorage.CurrentTaskID) !== -1 )
        //     {   
        //         DeactivateTask( localStorage.CurrentTaskID );
        //     }
        // }
        // localStorage.setItem( 'CurrentTaskID', TaskID );
        // ActivateTask( localStorage.CurrentTaskID );

    

}  // StartTimer


//------------------------------------------------------------------------------
//
//  Remove a task from the DOM and from local DOM storage.
//
//------------------------------------------------------------------------------
function RemoveTask( event )
{
    var $this     = $(this),
        DivID     = $this.attr('id'),
        TaskArr   = RetrieveTaskArr(),
        TaskDelim = DivID.indexOf('_'),
        TaskID    = DivID.substring(0, TaskDelim);

    //  Remove the Task from DOM storage.
    delete TaskArr[TaskID];
    SaveTaskArr( TaskArr );

    if ( localStorage.CurrentTaskID == TaskID )
    {
        //  If the task we're removing is the CurrentTaskID,
        //  stop the timer and clear the related IntervalID.
        clearInterval( IntervalID );
        IntervalID = 0;
        localStorage.setItem( 'CurrentTaskID', -1 );
    }

    //  By removing the parent DIV, we remove the entire task from the DOM.
    $this.parent().remove();

} // RemoveTask


//------------------------------------------------------------------------------
//
//  Via CSS, highlight the task chiclet currently under the curser.
//
//------------------------------------------------------------------------------
function MouseEnterTask( event )
{
    
    var $this       = $(this),
        DivID       = $this.attr('id'),
        TaskArr,
        TaskDelim   = DivID.indexOf('_'),
        TaskID      = DivID.substring(0, TaskDelim),
        MainTaskDiv = $this.find( '.task_div' );

    if ( MainTaskDiv.hasClass('task_inactive') )
    {
        MainTaskDiv.removeClass( 'task_inactive' )
                   .addClass( 'task_mouseover' );

    }
    else if ( MainTaskDiv.hasClass('task_current') )
    {
        MainTaskDiv.removeClass( 'task_current' )
                   .addClass( 'task_current_mouseover' );
    }

    $this.find( '#' + TaskID + '_remove' ).show();

} // MouseEnterTask


//------------------------------------------------------------------------------
//
//  Set the CSS of the task chiclet to un-highlighted.
//
//------------------------------------------------------------------------------
function MouseLeaveTask( event )
{
    var $this       = $(this),
        DivID       = $this.attr('id'),
        TaskArr,
        TaskDelim   = DivID.indexOf('_'),
        TaskID      = DivID.substring(0, TaskDelim),
        MainTaskDiv = $this.find( '.task_div' );

    if ( MainTaskDiv.hasClass('task_mouseover') )
    {
        MainTaskDiv.removeClass( 'task_mouseover' )
                   .addClass( 'task_inactive' );
    }
    else if ( MainTaskDiv.hasClass('task_current_mouseover') )
    {
        MainTaskDiv.removeClass( 'task_current_mouseover' )
                   .addClass( 'task_current' );
    }

    $this.find( '#' + TaskID + '_remove' ).hide();

} // MouseLeaveTask


//------------------------------------------------------------------------------
//
//  Add a task to the TaskArr in local DOM storage and to the DOM.
//
//------------------------------------------------------------------------------
function AddTask( TaskID, Task )
{
    var CloseButtonDiv,
		DropDiv,
        HoursMinsSecs = {},
        MainTaskDiv,
        TaskDiv,
        TaskArr_JSON,
        TaskArr = RetrieveTaskArr(),
        Time = 0;

    //
    //  If we haven't yet run across this task, save it into local DOM
    //  storage.
    //  Note:  the task may be in local DOM storage from a previous page
    //  instance even though it's not in the DOM.
    if ( !(TaskID in TaskArr) )
    {
        TaskArr[TaskID] = Task;
        SaveTaskArr( TaskArr );
    }

    // Recover a timer that was running when the page was last closed.
    if ( parseInt(Task.ElapsedSince) > 0 )
    {
        Time = parseInt( Task.TotElapsedTime ) + parseInt( Task.ElapsedSince );
        Task.TotElapsedTime = Time.toString();
        Task.Timestamp      = "0";
        TaskArr[TaskID]     = Task;
        SaveTaskArr( TaskArr );
    }

    HoursMinsSecs = ConvertMillisecondsToHoursMinsSecs( parseInt(Task.TotElapsedTime) );

    $( '#TaskList' ).append( MainTaskDiv );

} // AddTask 


//------------------------------------------------------------------------------
//
//  The 'drop' event handler for each drop target. Each task chiclet has a drop
//  target at the bottom. In addition, there's a drop target at the very top of
//  the task list that isn't attached to a task chiclet.
//
//------------------------------------------------------------------------------
function dropOnTarget( event )
{
    var TaskID = event.originalEvent.dataTransfer.getData('application/x-taskid'),
        $theTask = $( '#' + TaskID + '_main' ),
        $this = $(this);

    //
    // Shrink the drop target back to normal size.
    $this.prop( "class", "drop_target" );

    //
    // If a task chiclet has been dropped on its own drop target, then
    // we're done here.
    if ( $theTask.data('taskid') === $this.parent().data('taskid') )
    {
        return( false );
    }

    //
    // Remove the dragged and dropped task from the DOM and reattach it in the
    // dropped location.

    $theTask.detach();

    if ( $this.prop('id') === 'top_drop' ) {
        $this.after( $theTask );
    } else {
        $this.parent().after( $theTask );
    }

    return( false );
}


//------------------------------------------------------------------------------
//
//  When a task is dragged over a drop target, enlarge the target—via CSS—to
//  indicate that the task can be dropped.
//
//------------------------------------------------------------------------------
function activateDropTarget( event )
{
	event.preventDefault();
	event.stopPropagation();

    $(this).prop( "class", "active_drop_target" );

	return false;
}


//------------------------------------------------------------------------------
//
//  Shrink a drop target when a 'dragleave' event occurs.
//
//------------------------------------------------------------------------------
function deactivateDropTarget( event )
{
	event.preventDefault();
	event.stopPropagation();

    $(this).prop( "class", "drop_target" );

	return false;
}


//------------------------------------------------------------------------------
//
//  Submit handler for task submission form at top of page.
//
//------------------------------------------------------------------------------
function SubmitTask(project, task, user)
{
    var project = project;
    var task = task;
    var user = JSON.parse(user);
    
    var TaskName = task.task_title;
    var ProjectName = project.project_title;

    StartTimer = 0;

    event.preventDefault();
    event.stopPropagation();

    if ( TaskName.length > 0  && ProjectName.length > 0)
    {
        //  task already exists.
        TaskArr = RetrieveTaskArr();

        TaskExists = TaskAlreadyExistsinArr( TaskArr, TaskName );
        if ( ! TaskExists )
        {
            //  Add the task to local DOM storage and to the DOM.
            TaskID = NextTaskID();
            AddTask( TaskID,
                      { 'TaskId'        : task.task_id,
                        'ProjectId'     : project.project_id,
                        'Name'          : TaskName,
                        'ProjectName'   : ProjectName,
                        'TaskDate'      : CurrentDate(),
                        'Timestamp'     : 0,
                        'TotElapsedTime': 0,
                        'ElapsedSince'  : task.toelapsed_since } );

            if ( StartTimer == 0 )
            { 
                //  The user wants the timer started once the task has been
                //  added to the DOM.  To start the timer, simulate a click
                //  event on the task chiclet.
                // $( '#' + TaskID ).trigger( 'click' );
                localStorage.setItem('TaskTimeStamp', parseInt(Date.now().toString()));
            }

        }

    }

    return ( TaskID );

} // SubmitTask