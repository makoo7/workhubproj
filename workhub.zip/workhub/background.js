// idle time tracking code start
var laststate = null;
var laststatetime = null;
var shouldStop = false;
var streamMedia = null;
var IsPause = false;
var  idlecount = 0;
var activecount = 0;
const SYS_CURRENT_TIME = new Date(); // for now
const URL = "https://app.marketermagic.com/api/Workhub/";
// const URL = "http://192.168.5.143/marketing-magics/public/api/Workhub/";

function CurrentDate(){
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();
    
    if (dd < 10) { dd = '0' + dd; }
    if (mm < 10) { mm = '0' + mm; }
    
        var date =  dd+'-'+mm+'-'+yyyy;
            return date.toString();
}

function GetDate(d) {
    var today = new Date(d);
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) { dd = '0' + dd; }
    if (mm < 10) { mm = '0' + mm; }
    return dd+'-'+mm+'-'+yyyy;
}

function getDateTime(d){
    var time = new Date(d);
    var dd = time.getDate();
    var mm = time.getMonth() + 1; //January is 0!
    var yyyy = time.getFullYear();
    var hrs = time.getHours();
    var minutes = time.getMinutes();
    var seconds = time.getSeconds();

    if (dd < 10) { dd = '0' + dd; }
    if (mm < 10) { mm = '0' + mm; }
    return yyyy+'-'+mm+'-'+dd+' '+hrs+':'+minutes+':'+seconds;
}

function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}

// fetch current time to next hour difference code start
function fetchTimeDiff(Task, User, stream, shouldStop) {
    if(shouldStop === true){  chrome.runtime.reload(); stream = null;  }

    if(stream != null && stream !== false){ 
        streamMedia = stream;
    if(localStorage.getItem('EventAgeStamps')){
            var EventAgeStampsObj = JSON.parse(localStorage.getItem('EventAgeStamps'));
            var capturetime = new Date();
            var capturemin = capturetime.getMinutes();
            var seconds = capturetime.getSeconds();
            var screens = EventAgeStampsObj.screens;
            for(i=0; i< screens.length; i++ ) {
				var j=0;
                if((capturemin == screens[i]) && (seconds > 15 && seconds < 17)){
                    IsPause = false;
                    var mediaRecorder = new MediaRecorder(stream, {mimeType: 'video/webm'});
                    mediaRecorder.addEventListener('dataavailable', event => {
                            if (event.data && event.data.size > 100000) {
                                    mediaRecorder.pause();
                                file = new File([event.data], getFileName('mp4'), {
                                    type: 'video/mp4'
                                });
                                if(file.size > 100000){
                                    mediaRecorder.pause();
                                    if(j == 0){ 
										IsPause = true; 
                                    mediaRecorder.pause();
                                        // cross platform screen capture ajax code start.
                                        CrossPlatformScreens(file,j);
                                        // cross platform screen capture ajax code ends.
                                    } 
									j++;
								mediaRecorder.pause();
                                }
							mediaRecorder.pause();
                            }
						mediaRecorder.pause();
                    });
				
                    if(IsPause === false){
                        mediaRecorder.start(5000);
                    }
                }
              }
            }
            stream.getVideoTracks()[0].onended = function () {
                SetCounter(false);
                localStorage.removeItem('EventAgeStamps');
                localStorage.removeItem('TaskTimeStamp');
                localStorage.removeItem('TaskArr');
                localStorage.setItem('CurrentTaskID', -1);
                StopTimerShow();
            };
        }else{
            
            SetCounter(false);
                localStorage.removeItem('EventAgeStamps');
                localStorage.removeItem('TaskTimeStamp');
                localStorage.removeItem('TaskArr');
                localStorage.setItem('CurrentTaskID', -1);
            StopTimerShow();
            chrome.runtime.reload(); stream = null; 
        }

    var currtime = SYS_CURRENT_TIME;
    var curhrs = currtime.getHours();
    var curmins = currtime.getMinutes();
    var sec = currtime.getSeconds();
    var seconds = checkTime(sec);
    var currentDates = CurrentDate();
    var nexttime = new Date();
    nexttime.setHours(nexttime.getHours() + 1);
    var minseconds  = curmins+':'+seconds;
    var nexthrs = 0;
    var remainmmins = 0;
    var task = JSON.parse(localStorage.getItem('TaskArr'));
    var user = JSON.parse(User);
    var taskdate = task.TaskDate;
    var nexthrs = nexttime.getHours();
    remainmmins = 60 - curmins;

    if(currentDates == taskdate){
        if(localStorage.getItem('EventAgeStamps')){  threshold = 15;
                var EventAgeStampsObj = JSON.parse(localStorage.getItem('EventAgeStamps'));
                chrome.idle.queryState(threshold, function (state) {
                    var time = new Date();
                    if (laststate != state) {  laststate = state; laststatetime = time; }
                    if (state == "idle") { idlecount++; } else { activecount++; }
                    EventAgeStampsObj.ictn = idlecount;
                    EventAgeStampsObj.actn = activecount;
                    localStorage.setItem('EventAgeStamps', JSON.stringify(EventAgeStampsObj));
                });
        }else{
                idlecount = 0, activecount = 0;
                var time = new Date();
                var minutes = time.getMinutes();
                var curhrs = time.getHours();     
                // ictn: idle count, actn: active count, pid: project id, tid: task id, 
                // uid: user id, datetime: date time, stm : current min, stpm: next 15 min.
                // currenthrs: current hours
                if(localStorage.getItem('UserSettings')) {  //if custom settings exists for screens and minutes code start
                    var UserSettings = JSON.parse(localStorage.getItem('UserSettings'));
                    var nextminsetting = UserSettings.minutes;
                    var totscrsetting = UserSettings.screens;
                    var screens = [];
                    var nexttime = new Date();
                    nexttime.setMinutes(nexttime.getMinutes() + +nextminsetting);
                    var currentdatetime = time;
                    var nextfifteenmin = nexttime;
                    var nextmins = +minutes + +nextminsetting;
                    if(minutes > 45){     
                        if(nextmins == 60){ nextmins = 59; }
                        if(nextmins > 60){ curhrs = curhrs +1; nextmins = nextmins - 60; }     
                    }
                    if(minutes > 45){  var min = minutes; var max = 59;
                        for(ii = 0; ii< +totscrsetting; ii++){ var randnum = getRandomArbitrary(min, max); screens.push(randnum); }
                    }else{
                        var min = minutes; var max = nextmins;
                        for(ii = 0; ii< +totscrsetting; ii++){  var randnum = getRandomArbitrary(min, max); screens.push(randnum); }
                    } //if custom settings exists for screens and minutes code ends                   

                }else{ //if custom settings not exists for screens and minutes code start
                    // var nexttime = new Date();
                    // nexttime.setMinutes(nexttime.getMinutes() + 10);
                    // var currentdatetime = time;
                    // var nextfifteenmin = nexttime;
                    // var screens = []; var nextmins = +minutes + 10;
                    // if(minutes > 45){
                    //     if(nextmins == 60){ nextmins = 59; }
                    //     if(nextmins > 60){ curhrs = curhrs +1;  nextmins = nextmins - 60; }     
                    // }
                    var screens = []; 
                    var nexttime = new Date();
                    // var nextfifteenmin = nexttime;
                    /* Time Arrangement Starts */
                    var currentdatetime = time;
                    var nextMin = nexttime.getMinutes();
                    var intervalMin = 10;

                    if(nextMin % intervalMin == 0){
                        // assign to next interval mins
                        nexttime.setMinutes(nexttime.getMinutes() + intervalMin);
                        var nextmins = nexttime.getMinutes();
                        if(nextmins == 0 || nextmins == 60){
                            var curhrs = nexttime.getHours();
                        }
                    }else{
                        // assign to upcoming interval
                        var mod = nextMin % intervalMin;
                        var next2 = ( nexttime.getMinutes() + intervalMin ) - mod;
                        nexttime.setMinutes(next2);
                        var nextmins = next2;
                        if(nextmins == 0 || nextmins == 60){
                            var curhrs = nexttime.getHours();
                        }
                    }

                    // if(minutes > 50 && minutes <= 58){
                    //     var nextmins = 59;
                    // }else if(minutes == 59){
                    //     var minutes = 1;
                    //     var nextmins = 10;
                    //     nexttime.setHours(nexttime.getHours() + 1);
                    //     var curhrs = nexttime.getHours();
                    // }
                    /* Time Arrangement Ends */

                    if(minutes > 50){var min = minutes; var max = 59; var randnum1 = getRandomArbitrary(min, max); var randnum2 = getRandomArbitrary1(min, max);
                        var randnum3= getRandomArbitrary2(min, max); screens.push(randnum1,randnum2,randnum3);
                    }else{ var min = minutes;  var max = nextmins; var randnum1 = getRandomArbitrary(min, max); var randnum2 = getRandomArbitrary1(min, max);
                        var randnum3 = getRandomArbitrary2(min, max); screens.push(randnum1,randnum2,randnum3);
                    }  //if custom settings not exists for screens and minutes code ends

                }
                var EventAgeStampsObj = {'ictn': 0, 'actn': 0, 'pid': task.ProjectId, 
                                          'tid': task.TaskId, 'uid':  user.user_token, 
                                          'datetime': new Date(), 'stm': minutes, 
                                          'stpm': nextmins, 'currenthrs': curhrs, 'currenttime': currentdatetime, 'nextmins' : nextmins, 'screens': screens };

                    localStorage.setItem('EventAgeStamps', JSON.stringify(EventAgeStampsObj));
            }
        }
    }

function getRandomArbitrary(min, max){  var rand =  Math.ceil(Math.random() * (max - min) + min); return rand; }
function getRandomArbitrary1(min, max){ var rand =  Math.ceil(Math.random() * (max - min) + min); return rand; }
function getRandomArbitrary2(min, max){ var rand =  Math.ceil(Math.random() * (max - min) + min); return rand; }
//------------------------------------------------------------------------------
//  Convert some number of millisconds to hours, minutes, and seconds and return
//  the converted value.
//------------------------------------------------------------------------------
function ConvertMillisecondsToHoursMinsSecs(Milliseconds){
var NumMillisecondsInHour = 3600000,NumMillisecondsInMinute = 60000,NumMillisecondsInSecond = 1000,Hours = 0,Minutes = 0,Seconds = 0;
    if (Milliseconds >= NumMillisecondsInHour){  Hours = Math.floor(Milliseconds / NumMillisecondsInHour);  Milliseconds %= NumMillisecondsInHour; }
    if (Milliseconds >= NumMillisecondsInMinute) { Minutes = Math.floor(Milliseconds / NumMillisecondsInMinute); Milliseconds %= NumMillisecondsInMinute; }
    if (Milliseconds >= NumMillisecondsInSecond) { Seconds = Math.round(Milliseconds / NumMillisecondsInSecond); }
    if(Hours.toString().length  == 1){ Hours = '0'+Hours; }
    if(Minutes.toString().length  == 1){ Minutes = '0'+Minutes; }
    if(Seconds.toString().length  == 1){ Seconds = '0'+Seconds; }
    return ({ 'Hours': Hours, 'Minutes': Minutes, 'Seconds': Seconds });
}
//------------------------------------------------------------------------------
//  Convert some number of millisconds to hours, minutes, and seconds and return
//  the converted value.
//------------------------------------------------------------------------------
function SetCounter(flag) {
    if ((localStorage.getItem('CurrentTaskID') != -1) && (localStorage.getItem('CurrentTaskID')) && localStorage.getItem('user') && localStorage.getItem('TaskArr') &&
        (localStorage.getItem('TaskTimeStamp') != 0) && (flag == true)) {
        setInterval(function () {
            if(localStorage.getItem('TaskArr')){
                var CurrentTaskID = localStorage.getItem('CurrentTaskID'); var Taskdetail = JSON.parse(localStorage.getItem('TaskArr'));
                Interval = 0; var Task = Taskdetail, TotElapsedTime = parseInt(Task.TotElapsedTime), TaskTimestamp = parseInt(Task.Timestamp);
                Interval = TaskTimestamp - TotElapsedTime;
                HoursMinsSecs = ConvertMillisecondsToHoursMinsSecs(parseInt(Interval));
                Task.ElapsedSince = Interval.toString();
                Task.Timestamp = Date.now().toString();
                localStorage.setItem('TaskArr', JSON.stringify(Task));
                // fetch current time to next hour difference code ends
                var User = localStorage.getItem('user');
                // alert(streamMedia);
                fetchTimeDiff(Task, User, streamMedia, false);
                if(localStorage.getItem('EventAgeStamps')){  
                var EventAgeStamps = JSON.parse(localStorage.getItem('EventAgeStamps'));
                var time = new Date(); var minutes = time.getMinutes(); var seconds = time.getSeconds();
                    if((localStorage.getItem('EventAgeStamps') && (+EventAgeStamps.stpm == minutes) && (seconds > 55 && seconds == 56))){
                    PostTimerActivity();
                    }else{ return false; }
                }
            }else{ return false; }
        }, 1000);
    }else{ return false; }
}
// Start Counter 
SetCounter(true);

chrome.runtime.onMessage.addListener( function (request, sender, sendResponse) {
        if(request.greeting == "start") { sendResponse({ farewell: "welcome" }); SetCounter(true); }
        if(request.greeting == "logout") { sendResponse({ farewell: "goodbye" }); logoutsuccessshow(); }
        if(request.greeting == "loginsuccess") { sendResponse({ farewell: "welcome" }); loginsuccessshow(); }
        if(request.greeting == "startTimer") { sendResponse({ farewell: "welcome" }); StartTimershow(); _startScreenCapture(); }
        if(request.greeting  == "logoutTimer") {  SetCounter(false); sendResponse({ farewell: "goodbye" }); StopTimerShow(); fetchTimeDiff(null,null,null, true); }
        if(request.greeting == "JustStartRecord") { sendResponse({ farewell: "Correct" }); _startScreenCapture(); }
});

function PostTimerActivity(){
  var http = new XMLHttpRequest();  var url = URL+"task/timerslice";  var params = JSON.parse(localStorage.getItem('EventAgeStamps'));
  http.open('POST', url, true);
  var data = new FormData();  data.append('ictn', params.ictn); data.append('actn', params.actn); data.append('pid', params.pid);
  data.append('tid', params.tid); data.append('uid', params.uid); data.append('datetime', params.datetime); data.append('stm', params.stm);
  data.append('stpm', params.stpm); data.append('currenttime', params.currenttime); data.append('nextmins', params.nextmins); data.append('currenthrs', params.currenthrs);
  http.onreadystatechange = function() {
            if(http.readyState == 4 && http.status == 200) {
                var data = JSON.parse(http.responseText);
                var status = data.response.resp_status;
                if(status == "success") {
                    localStorage.removeItem('EventAgeStamps');
                }
            }
        }
  http.send(data);
}
// capture code start
// var id = 100;
// function capture() {
//     chrome.tabs.captureVisibleTab(function(screenshotUrl) {
//       var viewTabUrl = chrome.extension.getURL('screenshot.html?id=' + id++)
//       var imgobj = screenshotUrl;
//       if(typeof imgobj !== "undefined"){   
//           var http = new XMLHttpRequest(); var url = URL+"task/screencapture";
//             http.open('POST', url, true);  var data = new FormData(); data.append('imgobj', imgobj); data.append('task', localStorage.getItem('TaskArr'));
//             http.onreadystatechange = function() {
//                     if(http.readyState == 4 && http.status == 200) { console.clear(); }
//             }
//             http.send(data);
//         } 
//     });
// }
// capture code ends

// browser notification code starts
function loginsuccessshow() {  var user = JSON.parse(localStorage.getItem('user'));
    if(typeof user !== "undefined") {
        new Notification('Workhub', {
            icon: 'images/main-icon.png',
            body: 'Signed in as '+user.name
        });
    }
}
function logoutsuccessshow() {
    new Notification('Workhub', {
        icon: 'images/main-icon.png',
        body: 'Signed Out'
    });
}
function StartTimershow() {
    var task = JSON.parse(localStorage.getItem('TaskArr'));
    if(typeof task !== "undefined") {
        new Notification('Workhub', {
            icon: 'images/main-icon.png',
            body: 'Started tracking project '+task[1].ProjectName
        });
    }
}
function StopTimerShow() {
    new Notification('Workhub', {
        icon: 'images/main-icon.png',
        body: 'Stop Task tracking'
    });
}
// browser notification code ends
const DESKTOP_MEDIA = ['screen'];
var pending_request_id = null;
function _startScreenCapture(){
        pending_request_id = chrome.desktopCapture.chooseDesktopMedia(
        DESKTOP_MEDIA, onAccessApproved);
}
function onAccessApproved(id, options) {
    if (!id) {
      SetCounter(false);
      StopTimerShow();
      localStorage.removeItem('TaskTimeStamp');
      localStorage.removeItem('TaskArr');
      localStorage.setItem('CurrentTaskID', -1);
      return false;
    }
    navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            mandatory: {
              chromeMediaSource: 'desktop',
              chromeMediaSourceId: id,
              maxWidth:screen.width,
              maxHeight:screen.height} }
        }).then(function(stream) {
            // gotStream(stream, event);
            var Task = JSON.parse(localStorage.getItem('TaskArr'));
            var User = localStorage.getItem('user');
            fetchTimeDiff(Task, User, stream, false);
            SetCounter(true);
    });
}
function getRandomString() {
    if (window.crypto && window.crypto.getRandomValues && navigator.userAgent.indexOf('Safari') === -1) {
        var a = window.crypto.getRandomValues(new Uint32Array(3)),
            token = '';
        for (var i = 0, l = a.length; i < l; i++) {
            token += a[i].toString(36);
        }
        return token;
    } else {
        return (Math.random() * new Date().getTime()).toString(36).replace(/\./g, '');
    }
}
function getFileName(fileExtension) {
            var d = new Date();
            var year = d.getUTCFullYear() + '';
            var month = d.getUTCMonth() + '';
            var date = d.getUTCDate() + '';

            if(month.length === 1) {
                month = '0' + month;
            }

            if(date.length === 1) {
                date = '0' + date;
            }
            return year + month + date + getRandomString() + '.' + fileExtension;
}
function CrossPlatformScreens(file, i) {
    if(typeof file !== "undefined" && i == 0)
    {
                var http = new XMLHttpRequest();
                var url = URL+"task/screensharingtask";
                http.open('POST', url, true);
                var data = new FormData();
                data.append('imgobj', file);
                data.append('task', localStorage.getItem('TaskArr'));
                http.onreadystatechange = function() {
                    if(http.readyState == 4 && http.status == 200) {
                       console.clear();
                    }
                }
                http.send(data);
    } 
}